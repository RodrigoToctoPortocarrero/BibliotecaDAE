/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capaNegocio;

import capaDatos.clsJDBC;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JTable;

/**
 *
 * @author Edgar Bernabe
 */
public class clsVenta {

    clsJDBC objConectar = new clsJDBC();
    String strSQL;
    ResultSet rs = null;
    Connection con = null;
    Statement sent;

    public Integer generarCodigoVenta() throws Exception {
        strSQL = "SELECT COALESCE(max(numventa),0)+1 AS codigo FROM venta;";
        try {
            rs = objConectar.consultarBD(strSQL);
            while (rs.next()) {
                return rs.getInt("codigo");
            }
        } catch (Exception e) {
            throw new Exception("Error al generar código de venta");
        }
        return 0;
    }

    public ResultSet buscarVenta(Integer numVenta) throws Exception {
        String strSQL = "SELECT V.*,C.dni, C.ruc FROM venta V "
                + "inner join cliente C on V.codcliente=C.codcliente "
                + "WHERE numventa=" + numVenta;

        try {
            rs = objConectar.consultarBD(strSQL);
            return rs;
        } catch (Exception e) {
            throw new Exception("Error al buscar venta");
        }
    }

    public ResultSet listarDetalleVenta(Integer numVenta) throws Exception {
        String strSQL = "SELECT D.*,P.nomproducto FROM detalle D "
                + "inner join Producto P on D.codproducto=P.codproducto "
                + "WHERE numventa=" + numVenta;

        try {
            rs = objConectar.consultarBD(strSQL);
            return rs;
        } catch (Exception e) {
            throw new Exception("Error al listar detalle");
        }
    }

    public void registrar(String cod, String total, String subtotal, String igv,
            boolean tipo, String cliente, JTable tblDetalle) throws Exception {
        try {
            objConectar.conectar();
            con = objConectar.getCon();
            con.setAutoCommit(false);
            sent = con.createStatement();
            strSQL = "INSERT INTO venta VALUES (" + cod + ", CURRENT_DATE, " + total + ", "
                    + subtotal + ", " + igv + ", " + tipo + ", false, " + cliente + ");";
            sent.executeUpdate(strSQL);
            int ctd = tblDetalle.getRowCount();
            for (int i = 0; i < ctd; i++) {
                String descuento = tblDetalle.getValueAt(i, 4).toString();

                strSQL = "INSERT INTO detalle VALUES (" + cod + ", "
                        + tblDetalle.getValueAt(i, 0).toString() + ", "
                        + tblDetalle.getValueAt(i, 3).toString() + ", "
                        + tblDetalle.getValueAt(i, 5).toString() + ", "
                        + descuento.substring(0, descuento.length() - 1) + ", "
                        + tblDetalle.getValueAt(i, 6).toString() + ");";
                sent.executeUpdate(strSQL);
                strSQL = "UPDATE producto SET stock=stock-" + Integer.parseInt(tblDetalle.getValueAt(i, 3).toString())
                        + " WHERE codproducto = " + Integer.parseInt(tblDetalle.getValueAt(i, 0).toString()) + ";";
                sent.executeUpdate(strSQL);
            }
            con.commit();
        } catch (Exception e) {
            con.rollback();
            throw new Exception("Error al guardar Venta");
        } finally {
            objConectar.desconectar();
        }
    }
}
