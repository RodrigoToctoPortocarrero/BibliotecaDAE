/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capaNegocio;

import capaDatos.clsJDBC;
import java.sql.ResultSet;

/**
 *
 * @author Edgar Bernabe
 */
public class clsMarca {

    clsJDBC objConectar = new clsJDBC();
    String strSQL;
    ResultSet rs = null;

    public ResultSet listarMarcas() throws Exception {
        strSQL = "select * from marca";
        try {
            rs = objConectar.consultarBD(strSQL);
            return rs;
        } catch (Exception e) {
            throw new Exception("Error al listar marca --> " + e.getMessage());
        }
    }

    public Integer obtenerCodigoMarca(String nom) throws Exception {
        strSQL = "select codMarca from marca where nommarca='" + nom + "'";
        try {
            rs = objConectar.consultarBD(strSQL);
            if (rs.next()) {
                return rs.getInt("codMarca");
            }
        } catch (Exception e) {
            throw new Exception("Error al buscar marca" + e.getMessage());
        }
        return 0;
    }

    public Integer generarCodigoMarca() throws Exception {
        String strSQL = "Select COALESCE(Max(codMarca),0)+1 as codigo from marca";

        try {
            rs = objConectar.consultarBD(strSQL);

            while (rs.next()) {
                return rs.getInt("codigo");
            }
        } catch (Exception e) {
            throw new Exception("Error al generar codigo de marca --> " + e.getMessage());
        }
        return 0;
    }

    public void registrar(int cod, String nom, boolean vig) throws Exception {
        String strSQL = "insert into Marca values(" + cod + ", '" + nom + "', '" + vig + "')";
        try {
            objConectar.ejecutarBD(strSQL);
        } catch (Exception e) {
            throw new Exception("Error al registrar la marca --> " + e.getMessage());
        }
    }

    public ResultSet buscarMarca(Integer cod) throws Exception {
        strSQL = "select * from marca where codMarca=" + cod;
        try {
            rs = objConectar.consultarBD(strSQL);
            return rs;
        } catch (Exception e) {
            throw new Exception("Error al buscar marca" + e.getMessage());
        }
    }

    public void eliminarMarca(Integer cod) throws Exception {
        strSQL = "delete from marca where codMarca=" + cod;
        try {
            objConectar.ejecutarBD(strSQL);
        } catch (Exception e) {
            throw new Exception("Error al eliminar la marca" + e.getMessage());
        }
    }

    public void darBaja(Integer cod) throws Exception {
        strSQL = "update marca set vigencia=false where codMarca=" + cod;
        try {
            objConectar.ejecutarBD(strSQL);
        } catch (Exception e) {
            throw new Exception("Error al registrar la marca");
        }
    }

    public void modificar(Integer cod, String nom, Boolean vig) throws Exception {
        strSQL = "update marca set nomMarca='" + nom + "', vigencia=" + vig + " where codMarca=" + cod;
        try {
            objConectar.ejecutarBD(strSQL);
        } catch (Exception e) {
            throw new Exception("Error al modificar la marca");
        }
    }
}
