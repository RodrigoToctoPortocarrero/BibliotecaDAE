/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capaNegocio;

import Funciones.clsFunciones;
import capaDatos.clsJDBC;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author edgar bernabe
 */
public class usuario {
    //Crear instancia de la clase clsJDBC

    clsJDBC objConectar = new clsJDBC();
    String strSQL;
    ResultSet rs = null;

    public String login(String usu, String con) throws Exception {
        strSQL = "select nombrecompleto from usuario " + "where nomusuario = '" + usu + "' and clave = '" + con + "' and estado = 'true'";
        try {
            rs = objConectar.consultarBD(strSQL);
            while (rs.next()) {
                return rs.getString("nombrecompleto");
            }
        } catch (Exception e) {
            throw new Exception("Error al iniciar sesion. -->" + e.getMessage());
        }
        return "";
    }

    public Boolean validarVigencia(String usu) throws Exception {
        strSQL = "select estado from usuario where nomusuario = '" + usu + "'";
        try {
            rs = objConectar.consultarBD(strSQL);
            while (rs.next()) {
                return rs.getBoolean("estado");
            }
        } catch (Exception e) {
            throw new Exception("Error al validar usuario.-->" + e.getMessage());
        }
        return false;
    }

    public Boolean validarVigencia2(String usu) throws Exception {
        strSQL = "select estado from usuario2 where nomusuario = ?";
        try {
            Connection micon = null;
            objConectar.conectar();
            micon = objConectar.getCon();
            PreparedStatement sp = micon.prepareStatement(strSQL);
            sp.setString(1, usu);
            rs = sp.executeQuery();
            while (rs.next()) {
                return rs.getBoolean("estado");
            }
            objConectar.desconectar();
        } catch (Exception e) {
            throw new Exception("Error al validar usuario.");
        }
        return false;
    }

    public void login2(String usu, String con) throws Exception {
        strSQL = "select nombrecompleto, codusuario from usuario2 "
                + "where nomusuario=? and clave=md5(? || ? || 'FIJO383') and estado=true";
        boolean acceso = false;
        try {
            Connection micon = null;
            objConectar.conectar();
            micon = objConectar.getCon();
            PreparedStatement sp = micon.prepareStatement(strSQL);
            sp.setString(1, usu);
            sp.setString(2, con);
            sp.setString(3, usu);
            rs = sp.executeQuery();
            while (rs.next()) {
                clsFunciones.USUARIO_INICIO_SESION = rs.getString("nombrecompleto");
                clsFunciones.ID_INICIO_SESION = rs.getInt("codusuario");
                acceso = true;
            }
            objConectar.desconectar();
        } catch (Exception e) {
            throw new Exception("Error al iniciar sesión.\n" + e.getMessage());
        }
        if (!acceso) {
            clsFunciones.USUARIO_INICIO_SESION = "";
            clsFunciones.ID_INICIO_SESION = -1;
        }
    }

}
