package capaNegocio;
import capaDatos.clsJDBC;
import java.sql.*;

public class clsCambiarContraseña {
    clsJDBC objConectar = new clsJDBC();
    String strSQL;
    ResultSet rs = null;
    
    // Buscar pregunta de seguridad del usuario
    public String obtenerPreguntaSeguridad(String usuario) throws Exception {
        strSQL = "SELECT pregunta FROM usuario WHERE nomusuario = '" + usuario.trim() + "' AND estado = true";
        try {
            rs = objConectar.consultarBD(strSQL);
            if (rs.next()) {
                return rs.getString("pregunta").trim();
            }
            return null; // Usuario no existe
        } catch (Exception e) {
            throw new Exception("Error al buscar pregunta: " + e.getMessage());
        }
    }
    
    // Validar respuesta de seguridad
    public boolean validarRespuesta(String usuario, String respuesta) throws Exception {
        strSQL = "SELECT respuesta FROM usuario WHERE nomusuario = '" + usuario.trim() + "' AND estado = true";
        try {
            rs = objConectar.consultarBD(strSQL);
            if (rs.next()) {
                String respuestaDB = rs.getString("respuesta").trim().toLowerCase();
                return respuestaDB.equals(respuesta.trim().toLowerCase());
            }
            return false;
        } catch (Exception e) {
            throw new Exception("Error al validar respuesta: " + e.getMessage());
        }
    }
    public boolean validarContraseñaActual(String usuario, String contraseñaActual) throws Exception {
    strSQL = "SELECT clave FROM usuario WHERE nomusuario = '" + usuario.trim() + "' AND estado = true";
    try {
        rs = objConectar.consultarBD(strSQL);
        if (rs.next()) {
            String claveDB = rs.getString("clave").trim();
            return claveDB.equals(contraseñaActual);
        }
        return false;
    } catch (Exception e) {
        throw new Exception("Error al validar contraseña: " + e.getMessage());
    }
}
    
    // Cambiar contraseña
    public boolean cambiarContraseña(String usuario, String nuevaContraseña) throws Exception {
        strSQL = "UPDATE usuario SET clave = '" + nuevaContraseña + "' WHERE nomusuario = '" + usuario.trim() + "' AND estado = true";
        try {
            objConectar.ejecutarBD(strSQL);
            return true;
        } catch (Exception e) {
            throw new Exception("Error al cambiar contraseña: " + e.getMessage());
        }
    }
}