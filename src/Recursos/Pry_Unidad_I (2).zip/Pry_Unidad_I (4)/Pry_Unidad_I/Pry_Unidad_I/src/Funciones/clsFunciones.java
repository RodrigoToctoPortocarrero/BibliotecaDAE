package Funciones;

import java.text.SimpleDateFormat;
import java.util.Date;

public class clsFunciones {

    public static String USUARIO_INICIO_SESION;
    public static Integer ID_INICIO_SESION;

    public static String obtenerFechaActual() {
        Date fecha = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

        return formatoFecha.format(fecha);
    }

    public static String convertirDate(Date fecha) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");
        return formatoFecha.format(fecha);
    }
}
