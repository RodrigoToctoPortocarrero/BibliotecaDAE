/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package capaPresentacion;



/**
 *
 * @author edgar bernabe
 */
public class Pry_Unidad_I {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
/*probando la conexion
        int cont = 0;
        prueba objP = new prueba();
        ResultSet listado = objP.listarUsuarios();
        while (listado.next()) {
            cont++;
            String nombre = listado.getString("nomusuario");
            String sexo = listado.getString("sexo");
            System.out.println(nombre + "\t" + sexo);
        }

        System.out.println("Total de registros: " + cont);
    }*/

    frmMenuPrincipal objPrincipal = new frmMenuPrincipal();
    objPrincipal.setSize(1280,940);
    objPrincipal.setLocationRelativeTo(null);
    objPrincipal.setVisible(true);
    }

}
